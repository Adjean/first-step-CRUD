$(function (){
    $('table').DataTable();
    // create all our bills
    $('create').on('click', function (e) {
        let formOrder = $('formOrder')
        formOrder.serialize = function () {

        }
        if (formOrder[0].checkValidity()){
            e.preventDefault();
            $.ajax({
                url:'process.php',
                type:'post',
                data: formOrder.serialize()+'&action=create',
                sucess:function (response){
                    $('createModal').modal('hide');
                    Swal.fire({
                        icon:'success',
                        title:'success',
                    })
                    formOrder[0].reset();
                }
            })
        }
    })
})