<?php
require_once 'model.php';
//creating bill
if(isset($_POST['action']) && $_POST['action']=='create'){
    extract($_POST);
    $returned = (float)$received-(float)$amount;
    $db->create($customer, $cashier, (float)$amount, (float)$received, (float)$returned, $statut);
    echo "perfect";

}