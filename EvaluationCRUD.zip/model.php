<?php
class Database
{
    private $host ="mysql:dbname=dbcrud";
    private $user = "root";
    private $password = "";

    private function connexion()
    {
        try{
            new PDO($this->host, $this->user, $this->password);
        }catch (PDOException $e){
            die('Error:'.$e->getMessage());
        }
    }
    public function create(string $customer, string $cashier, float $amount, float $received, float $returned, string $statut)
    {
        $q=$this->connexion()->prepare("INSERT INTO bill(customer, cashier, amount, received, returned, statut) VALUES (:customer, :cashier, :amount, :received, :returned, :ststut)");
        return $q->execute([
            'customer'=> $customer,
            'cashier' => $cashier,
            'amount'  => $amount,
            'received'=> $received,
            'returned'=> $returned,
            'statut'  => $statut
        ]);
    }
}

